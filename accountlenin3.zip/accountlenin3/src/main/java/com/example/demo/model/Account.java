package com.example.demo.model;

public class Account {
	
	public int clientid;
	public String name;
	public int mmatriz;
	public int id;

}
