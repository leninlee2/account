package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

public class Person  implements Serializable {

	public int id;
	public String cpf;
	public String name;
	public Date birthday;
	public String cnpj;
	public String ein;
	
}
