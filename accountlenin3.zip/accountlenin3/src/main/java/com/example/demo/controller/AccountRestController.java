package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.data.AccountData;
import com.example.demo.data.PersonData;
import com.example.demo.model.Account;

@RestController
public class AccountRestController {
	
	@RequestMapping("/querymatriz")
    public List<Account> QueryMatriz() {
		List<Account> result = new AccountData().findAllMatriz();
		//Person ps = new Person();
		//ps.cpf = "123456";
		//persons.add(ps);
		
        return result;
    }
	
	@RequestMapping("/querymatrizall")
    public List<Account> QueryAll() {
		List<Account> result = new AccountData().findAll();
		//Person ps = new Person();
		//ps.cpf = "123456";
		//persons.add(ps);
		
        return result;
    }

}
