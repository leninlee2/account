package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {
	//@RequestParam(name="name", required=false, defaultValue="World") String name, Model model
	@GetMapping("/masteraccount")
	//@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public String Index() {
		//model.addAttribute("name", "Pure Batata");		
		return "master";
	}
	
	//spring.mvc.view.prefix=/WEB-INF/home/
	//spring.mvc.view.suffix=.jsp
	//Model model

}
