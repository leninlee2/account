package com.example.demo.data;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import javax.swing.tree.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.example.demo.model.Account;
import com.example.demo.model.Person;

public class AccountData {
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	SimpleDriverDataSource ds;
	
	public AccountData() {
		ds = new SimpleDriverDataSource();
        ds.setDriverClass(org.h2.Driver.class);
        ds.setUrl("jdbc:h2:~/test;DB_CLOSE_ON_EXIT=FALSE;AUTO_SERVER=TRUE");
        ds.setUsername("sa");
        ds.setPassword("");		
	}
	
	public Account findById(int id) {
	    return jdbcTemplate.queryForObject("select * from Account where id=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper<Account>(Account.class));
	}
	
	public List<Account> findAll() {
		List<Account> result = new ArrayList<Account>();
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        result = temp.query("select * from Account", new AccountRowMapper());
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		
		return result;
	}
	
	public List<Account> findAllMatriz() {
		List<Account> result = new ArrayList<Account>();
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        result = temp.query("select * from Account where PARENTID IS NULL ", new AccountRowMapper());
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		
		return result;
	}
	
	public void SaveChield(Account account) {
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        String command = "insert into Account(CLIENTID,DESCRIPTION,PARENTID,ACCOUNTDATE) values(?,?,?,CURRENT_TIMESTAMP())";
	        temp.update(command,new Object[] {account.clientid,account.name,account.mmatriz} );
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
	}
	
	public void SaveMatrixAccount(Account account) {
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        String command = "insert into Account(CLIENTID,DESCRIPTION,ACCOUNTDATE) values(?,?,CURRENT_TIMESTAMP())";
	        temp.update(command,new Object[] {account.clientid,account.name } );
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
	}

}

class AccountRowMapper implements RowMapper<Account> {
    @Override
    public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
    	Account ps = new Account();
        ps.id =   rs.getInt("id");
        ps.name = rs.getString("description");
        ps.clientid =  rs.getInt("CLIENTID");
        ps.mmatriz = rs.getInt("PARENTID");
        return ps;
    }
}
